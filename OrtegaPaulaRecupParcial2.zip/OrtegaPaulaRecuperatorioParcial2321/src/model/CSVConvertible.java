
package model;

import java.io.Serializable;


public interface CSVConvertible extends Serializable{
    
    public String toCSV();
    
}
