
package model;


public enum Categoria {
    AMBIENTAL,
    ASISTENCIA,
    SEGURIDAD
    
}
