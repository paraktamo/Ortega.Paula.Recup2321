package model;

import java.util.Objects;

public class DispositivoDomotico implements CSVConvertible, Comparable<DispositivoDomotico> {

    private int codigo;
    private String nombreModelo;
    private Categoria categoria;
    private int consumoWatts;
    private int anioFabricacion;

    public DispositivoDomotico(int codigo, String nombreModelo, Categoria categoria, int consumoWatts, int AnioFabricacion) {
        this.codigo = codigo;
        this.nombreModelo = nombreModelo;
        this.categoria = categoria;
        this.consumoWatts = consumoWatts;
        this.anioFabricacion = AnioFabricacion;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getConsumoWatts() {
        return consumoWatts;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    @Override
    public int compareTo(DispositivoDomotico o) {
        int comparador = Integer.compare(o.anioFabricacion, this.anioFabricacion);
        if (comparador == 0) {
            comparador = Integer.compare(this.consumoWatts, o.consumoWatts);
        }
        return comparador;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.codigo);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final DispositivoDomotico other = (DispositivoDomotico) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "DispositivoDomotico{" + "codigo=" + codigo + ", nombreModelo=" + nombreModelo + ", categoria=" + categoria + ", consumoWatts=" + consumoWatts + ", anioFabricacion=" + anioFabricacion + '}';
    }

    public static String toHeaderCSV() {
        return "codigo,nombreModelo,categoria,consumoWatts,anioFabricacion";
    }

    public static DispositivoDomotico fromCSV(String linea) {
        linea = linea.substring(0, linea.length());
        String[] datos = linea.split(",");
        return new DispositivoDomotico(Integer.parseInt(datos[0]), datos[1], Categoria.valueOf(datos[2]), Integer.parseInt(datos[3]), Integer.parseInt(datos[4]));
    }

    @Override
    public String toCSV() {
        return codigo + "," + nombreModelo + "," + categoria + "," + consumoWatts + "," + anioFabricacion;
    }
    
    public DispositivoDomotico correccionConsumo(int nuevoConsumo){
        return new DispositivoDomotico( this.codigo, this.nombreModelo, this.categoria, nuevoConsumo, this.anioFabricacion);
    }

}
