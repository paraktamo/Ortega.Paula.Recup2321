package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVConvertible & Comparable<T>> implements Almacenable<T>, Iterable<T> {

    private List<T> items;
    private static final long serialVersionUID = 1L;

    public Inventario() {
        this.items = new ArrayList<>();
    }

    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new NullPointerException("Entrada Invalida");
        }
        items.add(item);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        Iterator<T> it = items.iterator();
        while (it.hasNext()) {
            T elemento = it.next();
            if (criterio.test(elemento)) {
                it.remove();
            }
        }
    }

    public boolean estaVacio() {
        return this.items.isEmpty();
    }

    @Override
    public List<T> obtenerTodos() {
        if (this.estaVacio()) {
            throw new UnsupportedOperationException("No hay contenido en la lista");
        }
        return new ArrayList<>(this.items);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        if (this.estaVacio()) {
            throw new UnsupportedOperationException("No hay contenido en la lista");
        }
        for (T item : items) {
            if (criterio.test(item)) {
                return item;
            }
        }
        return null;
    }

    @Override
    public void ordenar() {
        Collections.sort(this.items);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        this.items.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> copia = new ArrayList<>();
        if (this.estaVacio()) {
            throw new UnsupportedOperationException("No hay contenido en la lista");
        }
        for (T item : items) {
            if (criterio.test(item)) {
                copia.add(item);
            }
        }
        return copia;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> copia = new ArrayList<>();

        for (T item : items) {
            copia.add(operador.apply(item));
        }
        return copia;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int cantidad = 0;

        for (T item : items) {
            if (criterio.test(item)) {
                cantidad++;
            }
        }
        return cantidad;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try (ObjectOutputStream guardador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            guardador.writeObject(this.items);

        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        try (ObjectInputStream desguardador = new ObjectInputStream(new FileInputStream(ruta))) {

            this.items = (List<T>) desguardador.readObject();

        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {

            if (!estaVacio()) {
                escritor.write(DispositivoDomotico.toHeaderCSV());
                escritor.write("\n");
            }

            for (T item : items) {
                escritor.write(item.toCSV());
                escritor.write("\n");
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            this.items.clear();

            lector.readLine();

            String linea;

            while ((linea = lector.readLine()) != null) {

                this.items.add(fromCSV.apply(linea));

            }
        }
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        throw new UnsupportedOperationException("No implementado");
    }

    @Override
    public Iterator iterator() {
        List<T> copia = new ArrayList<>(this.items);
        return copia.iterator();
    }

}
